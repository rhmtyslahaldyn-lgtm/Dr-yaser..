package com.dryaser.app;

import android.app.*;
import android.os.*;
import android.content.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.view.*;
import android.widget.*;
import java.util.*;
import java.text.*;

public class MainActivity extends Activity {
    static final int NAVY=0xFF061A2D, NAVY2=0xFF0B2945, CARD=0xFF102F4D, GOLD=0xFFF3D58A,
            WHITE=0xFFF8FAFC, MUTED=0xFF9FB3C8, GREEN=0xFF65C18C, RED=0xFFE58B8B;
    LinearLayout content, bottom;
    SharedPreferences pref;
    Handler handler=new Handler();
    long studySeconds=0, sessionStart=0;
    boolean running=false;
    TextView timer;
    final String[] subjects={"زیست","شیمی","فیزیک","ریاضی","زمین‌شناسی"};
    final String[] quotes={
      "هر تست، یک قدم به دندان‌پزشکی نزدیک‌ترت می‌کند 🦷",
      "قرار نیست کامل باشی؛ فقط امروز را جدی بگیر.",
      "آرام و پیوسته؛ نتیجه از استمرار ساخته می‌شود.",
      "آینده‌ی تو از انتخاب‌های کوچک امروز ساخته می‌شود.",
      "یک جلسه‌ی دیگر؛ یک قدم دیگر به هدف."
    };

    @Override public void onCreate(Bundle b){
        super.onCreate(b);
        getWindow().setStatusBarColor(NAVY); getWindow().setNavigationBarColor(NAVY);
        pref=getSharedPreferences("dryaser",0);
        studySeconds=pref.getLong("study",0);
        shell(); dashboard();
    }
    TextView tv(String s,float z,int c){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(z); t.setTextColor(c);
        t.setGravity(Gravity.RIGHT|Gravity.CENTER_VERTICAL); t.setPadding(6,5,6,5); return t;
    }
    TextView head(String s){ TextView t=tv(s,22,WHITE); t.setTypeface(null,1); t.setPadding(5,16,5,12); return t; }
    GradientDrawable shape(int c,float r){ GradientDrawable g=new GradientDrawable(); g.setColor(c); g.setCornerRadius(r); return g; }
    Button button(String s, boolean gold){
        Button b=new Button(this); b.setText(s); b.setTextSize(13); b.setAllCaps(false); b.setTextColor(gold?NAVY:WHITE);
        b.setBackground(shape(gold?GOLD:NAVY2,42)); return b;
    }
    LinearLayout card(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(18,15,18,15); l.setBackground(shape(CARD,28)); return l; }
    LinearLayout row(){ LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.HORIZONTAL); l.setGravity(Gravity.CENTER_VERTICAL); return l; }
    void add(LinearLayout p,View v,int h){p.addView(v,new LinearLayout.LayoutParams(-1,h));}
    void addW(LinearLayout p,View v,float w){p.addView(v,new LinearLayout.LayoutParams(0,-2,w));}

    void shell(){
        LinearLayout root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(NAVY);
        ScrollView sv=new ScrollView(this); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL); content.setPadding(18,4,18,92); sv.addView(content);
        root.addView(sv,new LinearLayout.LayoutParams(-1,0,1));
        bottom=row(); bottom.setPadding(6,5,6,5); bottom.setBackgroundColor(0xFF051524);
        String[] n={"خانه","برنامه","تایمر","آزمون","پیشرفت"};
        for(String x:n){ Button b=button(x,false); bottom.addView(b,new LinearLayout.LayoutParams(0,64,1));
            b.setOnClickListener(v->{if(x.equals("خانه"))dashboard(); else if(x.equals("برنامه"))schedule(); else if(x.equals("تایمر"))timerPage(); else if(x.equals("آزمون"))exams(); else progress();});
        }
        root.addView(bottom,new LinearLayout.LayoutParams(-1,72)); setContentView(root);
    }
    void clear(String s){content.removeAllViews();content.addView(head(s));}
    String fmt(long s){return String.format(Locale.US,"%02d:%02d:%02d",s/3600,(s/60)%60,s%60);}
    int goal(){return pref.getInt("goal",480);}
    int todayPct(){return (int)Math.min(100,studySeconds*100L/(goal()*60L));}
    long daysLeft(){Calendar t=Calendar.getInstance();t.set(2027,6,1,0,0,0);return Math.max(0,(t.getTimeInMillis()-System.currentTimeMillis())/86400000L);}

    void dashboard(){
        clear("🦷 دکتر یاسر");
        TextView h=tv("صبح بخیر یاسر 🌤️",20,WHITE);h.setTypeface(null,1);add(content,h,56);
        TextView q=tv("«"+quotes[pref.getInt("q",0)%quotes.length]+"»",15,GOLD);q.setGravity(Gravity.CENTER);add(content,q,74);
        LinearLayout hero=card();TextView a=tv("هدف نهایی: دندان‌پزشکی 🦷",19,GOLD);a.setGravity(Gravity.CENTER);a.setTypeface(null,1);hero.addView(a);
        TextView d=tv("تا تاریخ هدف: "+daysLeft()+" روز",16,WHITE);d.setGravity(Gravity.CENTER);hero.addView(d);add(content,hero,112);
        LinearLayout r=row(); String[][] st={{fmt(studySeconds),"مطالعه امروز"},{pref.getInt("tests",0)+"","تست امروز"},{"8 ساعت","هدف امروز"}};
        for(String[] x:st){TextView t=tv(x[0]+"\n"+x[1],13,WHITE);t.setGravity(Gravity.CENTER);t.setBackground(shape(NAVY2,24));addW(r,t,1);}
        content.addView(r,new LinearLayout.LayoutParams(-1,82));
        LinearLayout p=card();p.addView(tv("پیشرفت هدف روزانه",16,WHITE));TextView pc=tv(todayPct()+"٪",17,GOLD);pc.setGravity(Gravity.CENTER);pc.setBackground(shape(NAVY2,25));p.addView(pc,new LinearLayout.LayoutParams(-1,48));p.addView(tv("هدف و زمان‌بندی از تنظیمات قابل تغییر است.",13,MUTED));add(content,p,142);
        Button go=button("▶ شروع مطالعه",true);go.setOnClickListener(v->timerPage());add(content,go,58);
        Button pl=button("📅 برنامه امروز",false);pl.setOnClickListener(v->schedule());add(content,pl,58);
    }

    void schedule(){
        clear("📅 برنامه‌ریزی");
        TextView inf=tv("جلسه‌ها، زمان‌ها و درس‌ها را هر زمان خواستی ویرایش کن.",14,MUTED);add(content,inf,52);
        String[] times={"05:30–07:00","07:20–08:50","09:30–11:00","11:30–13:00","15:00–16:00","16:30–18:00","19:00–20:00"};
        String[] subs={"زیست","شیمی","فیزیک","ریاضی","مرور و تست","آزمون/تست ترکیبی","تحلیل و مرور"};
        for(int i=0;i<times.length;i++) session(i,times[i],subs[i]);
        Button add=button("＋ افزودن جلسه",true);add.setOnClickListener(v->edit("جلسه جدید","زمان جدید"));add(content,add,58);
        Button smart=button("🤖 ساخت برنامه هوشمند",false);smart.setOnClickListener(v->smartPlan());add(content,smart,58);
    }
    void session(int i,String time,String sub){
        LinearLayout c=card();LinearLayout r=row();TextView t=tv(time,12,GOLD);addW(r,t,1);TextView s=tv(sub,16,WHITE);s.setGravity(Gravity.CENTER);addW(r,s,1);
        Button e=button("ویرایش",false);e.setOnClickListener(v->edit(sub,time));r.addView(e,new LinearLayout.LayoutParams(100,52));c.addView(r);add(content,c,78);
    }
    void edit(String sub,String time){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(15,0,15,0);
        EditText s=new EditText(this);s.setHint("درس یا مبحث");s.setText(sub);s.setTextColor(WHITE);s.setHintTextColor(MUTED);
        EditText t=new EditText(this);t.setHint("زمان");t.setText(time);t.setTextColor(WHITE);t.setHintTextColor(MUTED);
        box.addView(s);box.addView(t);
        new AlertDialog.Builder(this).setTitle("ویرایش برنامه").setView(box).setPositiveButton("ذخیره",(d,w)->Toast.makeText(this,"ذخیره شد ✅",Toast.LENGTH_SHORT).show()).setNegativeButton("لغو",null).show();
    }
    void smartPlan(){
        new AlertDialog.Builder(this).setTitle("🤖 برنامه‌ریز هوشمند")
        .setMessage("بر اساس هدف "+goal()/60+" ساعت، برنامه پیشنهادی بین زیست، شیمی، فیزیک، ریاضی و زمین‌شناسی تقسیم می‌شود. هر بخش بعداً قابل ویرایش است.")
        .setPositiveButton("ساخت برنامه",(d,w)->{Toast.makeText(this,"برنامه پیشنهادی ساخته شد 📚",Toast.LENGTH_SHORT).show();schedule();})
        .setNegativeButton("لغو",null).show();
    }

    void timerPage(){
        clear("⏱️ تایمر مطالعه");
        timer=tv(fmt(studySeconds),40,GOLD);timer.setGravity(Gravity.CENTER);timer.setTypeface(null,1);add(content,timer,120);
        LinearLayout c=card();c.addView(tv("درس فعلی",15,WHITE));Spinner sp=new Spinner(this);
        sp.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,subjects));c.addView(sp,new LinearLayout.LayoutParams(-1,55));add(content,c,120);
        LinearLayout r=row();Button st=button("▶ شروع",true),stop=button("⏸ توقف",false),reset=button("↺ امروز از نو",false);
        r.addView(st,new LinearLayout.LayoutParams(0,60,1));r.addView(stop,new LinearLayout.LayoutParams(0,60,1));r.addView(reset,new LinearLayout.LayoutParams(0,60,1));content.addView(r);
        st.setOnClickListener(v->{if(!running){running=true;sessionStart=System.currentTimeMillis();handler.post(tick);}});
        stop.setOnClickListener(v->{if(running){studySeconds+=(System.currentTimeMillis()-sessionStart)/1000;running=false;persist();}});
        reset.setOnClickListener(v->{running=false;studySeconds=0;persist();timer.setText(fmt(0));});
        TextView info=tv("پومودورو: ۲۵ دقیقه مطالعه + ۵ دقیقه استراحت\nمدت هدف از تنظیمات قابل تغییر است.",14,MUTED);info.setPadding(6,22,6,5);add(content,info,95);
        Button inc=button("＋ ثبت ۱۰ تست",false);inc.setOnClickListener(v->{int n=pref.getInt("tests",0)+10;pref.edit().putInt("tests",n).apply();Toast.makeText(this,"تعداد تست امروز: "+n,Toast.LENGTH_SHORT).show();});add(content,inc,58);
    }
    Runnable tick=()->{if(running){long now=System.currentTimeMillis();timer.setText(fmt(studySeconds+(now-sessionStart)/1000));handler.postDelayed(tick,500);}};
    void persist(){pref.edit().putLong("study",studySeconds).apply();}

    void exams(){
        clear("📝 آزمون‌های قلم‌چی");
        LinearLayout c=card();c.addView(tv("آخرین نتیجه ثبت‌شده",17,WHITE));c.addView(tv("تراز: "+pref.getInt("rank",6870),25,GOLD));c.addView(tv("زیست 72٪   شیمی 61٪   فیزیک 54٪   ریاضی 43٪",14,MUTED));add(content,c,145);
        Button add=button("＋ ثبت آزمون جدید",true);add.setOnClickListener(v->examDialog());add(content,add,58);
        TextView h=tv("سوابق",17,WHITE);h.setPadding(4,18,4,8);add(content,h,50);
        String history=pref.getString("history","آزمون نمونه — تراز 6870");
        add(content,tv(history,14,MUTED),80);
    }
    void examDialog(){
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(15,0,15,0);
        EditText rank=new EditText(this);rank.setHint("تراز");rank.setInputType(2);rank.setTextColor(WHITE);
        EditText bio=new EditText(this);bio.setHint("درصد زیست");bio.setInputType(2);bio.setTextColor(WHITE);
        EditText chem=new EditText(this);chem.setHint("درصد شیمی");chem.setInputType(2);chem.setTextColor(WHITE);
        b.addView(rank);b.addView(bio);b.addView(chem);
        new AlertDialog.Builder(this).setTitle("ثبت آزمون قلم‌چی").setView(b).setPositiveButton("ثبت",(d,w)->{
            int rr=parse(rank.getText().toString(),6870);pref.edit().putInt("rank",rr).putString("history","آخرین آزمون — تراز "+rr+" | زیست "+bio.getText()+"٪ | شیمی "+chem.getText()+"٪").apply();
            Toast.makeText(this,"آزمون ذخیره شد 📊",Toast.LENGTH_SHORT).show();exams();
        }).setNegativeButton("لغو",null).show();
    }
    int parse(String s,int def){try{return Integer.parseInt(s);}catch(Exception e){return def;}}

    void progress(){
        clear("📊 پیشرفت");
        LinearLayout c=card();c.addView(tv("مطالعه امروز",17,WHITE));c.addView(tv(fmt(studySeconds),28,GOLD));c.addView(tv("هدف: "+goal()/60+" ساعت",14,MUTED));c.addView(new Graph(this),new LinearLayout.LayoutParams(-1,190));add(content,c,305);
        int[] v={72,61,54,43,80};for(int i=0;i<subjects.length;i++){LinearLayout r=row();addW(r,tv(subjects[i],15,WHITE),1);TextView p=tv(v[i]+"٪",15,GOLD);p.setGravity(Gravity.CENTER);r.addView(p,new LinearLayout.LayoutParams(80,54));content.addView(r);}
        Button settings=button("⚙ تنظیمات کامل",false);settings.setOnClickListener(vv->settings());add(content,settings,60);
    }
    void settings(){
        LinearLayout b=new LinearLayout(this);b.setOrientation(LinearLayout.VERTICAL);b.setPadding(15,0,15,0);
        EditText g=new EditText(this);g.setHint("هدف روزانه (دقیقه)");g.setText(""+goal());g.setInputType(2);g.setTextColor(WHITE);
        EditText wake=new EditText(this);wake.setHint("بیداری");wake.setText("05:00");wake.setTextColor(WHITE);
        EditText sleep=new EditText(this);sleep.setHint("خواب");sleep.setText("22:00");sleep.setTextColor(WHITE);
        b.addView(g);b.addView(wake);b.addView(sleep);
        new AlertDialog.Builder(this).setTitle("تنظیمات قابل تغییر").setView(b).setPositiveButton("ذخیره",(d,w)->{pref.edit().putInt("goal",parse(g.getText().toString(),480)).apply();Toast.makeText(this,"تنظیمات ذخیره شد ⚙️",Toast.LENGTH_SHORT).show();}).setNegativeButton("لغو",null).show();
    }

    class Graph extends View{
        Paint p=new Paint(1);Graph(Context c){super(c);}
        protected void onDraw(Canvas c){p.setColor(0xFF294B69);p.setStrokeWidth(2);for(int i=1;i<5;i++)c.drawLine(0,getHeight()*i/5f,getWidth(),getHeight()*i/5f,p);
            p.setColor(GOLD);p.setStrokeWidth(6);float[] a={.82f,.70f,.64f,.57f,.46f,.39f,.28f};float px=0,py=getHeight()*a[0];
            for(int i=1;i<a.length;i++){float x=getWidth()*i/(a.length-1f),y=getHeight()*a[i];c.drawLine(px,py,x,y,p);px=x;py=y;}
        }
    }
}
